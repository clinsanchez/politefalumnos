<?php
session_start();
if (!isset($_SESSION['uid'])) {
    header("Location: index.php");
    exit;
}

$username = $_SESSION['username'];

function odoo_request($model, $method, $args, $fields = []) {
    $url = 'http://TU_IP_O_DOMINIO_ODDO/jsonrpc';
    $data = [
        "jsonrpc" => "2.0",
        "method" => "call",
        "params" => [
            "service" => "object",
            "method" => "execute_kw",
            "args" => [
                "TU_NOMBRE_DE_BD",
                $_SESSION['uid'],
                "",
                $model,
                $method,
                $args,
                $fields ? ["fields" => $fields] : new stdClass()
            ]
        ],
        "id" => 1
    ];

    $options = [
        'http' => [
            'method'  => 'POST',
            'header'  => "Content-Type: application/json",
            'content' => json_encode($data)
        ]
    ];
    $context  = stream_context_create($options);
    $result = file_get_contents($url, false, $context);
    return json_decode($result, true)['result'];
}

$students = odoo_request("op.student", "search_read", [[["gr_no", "=", $username]]], ["id", "name"]);
if (count($students) == 0) {
    echo "<p>No se encontró al estudiante.</p>";
    exit;
}
$student_id = $students[0]['id'];
$grades = odoo_request("op.result.line", "search_read", [[["student_id", "=", $student_id]]], ["subject_id", "grade", "result_id"]);
$debt = odoo_request("account.move", "search_read", [[["student_id", "=", $student_id], ["state", "!=", "paid"]]], ["name", "amount_total", "invoice_date_due"]);

?>
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <title>Panel del Alumno</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body class="bg-light">
<div class="container py-4">
    <h2 class="mb-4">Bienvenido, <?php echo htmlspecialchars($students[0]['name']); ?></h2>

    <div class="card mb-4">
        <div class="card-header bg-primary text-white">Calificaciones</div>
        <ul class="list-group list-group-flush">
            <?php foreach ($grades as $g): ?>
                <li class="list-group-item">
                    <?php echo $g['subject_id'][1]; ?>: <strong><?php echo $g['grade']; ?></strong>
                </li>
            <?php endforeach; ?>
        </ul>
    </div>

    <div class="card mb-4">
        <div class="card-header bg-danger text-white">Deudas Pendientes</div>
        <ul class="list-group list-group-flush">
            <?php foreach ($debt as $d): ?>
                <li class="list-group-item">
                    Factura <?php echo $d['name']; ?> - <strong>$<?php echo $d['amount_total']; ?></strong><br>
                    Vence: <?php echo $d['invoice_date_due']; ?>
                </li>
            <?php endforeach; ?>
        </ul>
    </div>

    <a href='logout.php' class="btn btn-secondary">Cerrar sesión</a>
</div>
</body>
</html>
