<?php
session_start();
if (isset($_POST['username']) && isset($_POST['password'])) {
    $data = [
        "jsonrpc" => "2.0",
        "method" => "call",
        "params" => [
            "db" => "TU_NOMBRE_DE_BD",
            "login" => $_POST['username'],
            "password" => $_POST['password']
        ],
        "id" => 1
    ];

    $options = [
        'http' => [
            'method'  => 'POST',
            'header'  => "Content-Type: application/json",
            'content' => json_encode($data)
        ]
    ];

    $context  = stream_context_create($options);
    $result = file_get_contents('http://TU_IP_O_DOMINIO_ODDO/web/session/authenticate', false, $context);
    $response = json_decode($result, true);

    if (isset($response['result']['uid'])) {
        $_SESSION['uid'] = $response['result']['uid'];
        $_SESSION['username'] = $_POST['username'];
        header("Location: dashboard.php");
        exit;
    } else {
        $error = "Credenciales inválidas";
    }
}
?>
<!DOCTYPE html>
<html>
<head><title>Login Alumno</title></head>
<body>
<h2>Login Alumno</h2>
<form method="POST">
    Usuario (GRNO): <input type="text" name="username" required><br>
    Contraseña (CURP): <input type="password" name="password" required><br>
    <button type="submit">Ingresar</button>
</form>
<?php if (!empty($error)) echo "<p style='color:red;'>$error</p>"; ?>
</body>
</html>
